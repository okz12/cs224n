rm -f assignment2.zip
zip -r assignment2.zip *.py *.png saved_params_40000.npy
